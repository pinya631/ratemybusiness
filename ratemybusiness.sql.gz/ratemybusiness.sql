-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2018 at 11:49 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ratemybusiness`
--
CREATE DATABASE IF NOT EXISTS `ratemybusiness` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `ratemybusiness`;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_year_established` year(4) NOT NULL,
  `company_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ref_company_reviews`
--

CREATE TABLE `ref_company_reviews` (
  `rcr_id` int(11) NOT NULL,
  `rcr_company_id` int(11) NOT NULL,
  `rcr_rev_id` int(11) NOT NULL,
  `rcr_reviewer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ref_user_company`
--

CREATE TABLE `ref_user_company` (
  `ruc_id` int(11) NOT NULL,
  `ruc_user_id` int(11) NOT NULL,
  `ruc_company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reviewers`
--

CREATE TABLE `reviewers` (
  `reviewer_id` int(11) NOT NULL,
  `reviewer_firstname` varchar(255) NOT NULL,
  `reviewer_lastname` varchar(255) NOT NULL,
  `reviewer_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `review_rating` tinyint(5) NOT NULL,
  `review_comment` longtext NOT NULL,
  `review_date_created` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_first_name` varchar(255) NOT NULL,
  `user_last_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `ref_company_reviews`
--
ALTER TABLE `ref_company_reviews`
  ADD PRIMARY KEY (`rcr_id`),
  ADD KEY `rcr_company_id` (`rcr_company_id`),
  ADD KEY `rcr_rev_id` (`rcr_rev_id`),
  ADD KEY `rcr_rev_id_2` (`rcr_rev_id`),
  ADD KEY `rcr_reviewer_id` (`rcr_reviewer_id`);

--
-- Indexes for table `ref_user_company`
--
ALTER TABLE `ref_user_company`
  ADD PRIMARY KEY (`ruc_id`),
  ADD KEY `ruc_user_id` (`ruc_user_id`),
  ADD KEY `ruc_company_id` (`ruc_company_id`);

--
-- Indexes for table `reviewers`
--
ALTER TABLE `reviewers`
  ADD PRIMARY KEY (`reviewer_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ref_company_reviews`
--
ALTER TABLE `ref_company_reviews`
  MODIFY `rcr_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ref_user_company`
--
ALTER TABLE `ref_user_company`
  MODIFY `ruc_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviewers`
--
ALTER TABLE `reviewers`
  MODIFY `reviewer_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ref_company_reviews`
--
ALTER TABLE `ref_company_reviews`
  ADD CONSTRAINT `ref_company_reviews_ibfk_1` FOREIGN KEY (`rcr_reviewer_id`) REFERENCES `reviewers` (`reviewer_id`),
  ADD CONSTRAINT `ref_company_reviews_ibfk_2` FOREIGN KEY (`rcr_rev_id`) REFERENCES `reviews` (`review_id`),
  ADD CONSTRAINT `ref_company_reviews_ibfk_3` FOREIGN KEY (`rcr_company_id`) REFERENCES `company` (`company_id`);

--
-- Constraints for table `ref_user_company`
--
ALTER TABLE `ref_user_company`
  ADD CONSTRAINT `ref_user_company_ibfk_1` FOREIGN KEY (`ruc_user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `ref_user_company_ibfk_2` FOREIGN KEY (`ruc_company_id`) REFERENCES `company` (`company_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
